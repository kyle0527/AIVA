"""
AIVA Data Ingestion Module

數據攝取和處理模組。
"""

__version__ = "1.0.0"

# 暫時沒有實現，預留接口
__all__ = []
